import React from 'react'






function Work() {
  return (
    <div className='text-center w-32 text-4xl  m-auto mt-32 mb-24 font-bold border-solid border-b-4 border-red-300 text-gray-500'>Work</div>
  )
}

export default Work