import React from 'react'

function Project() {
  return (
    <div>Project</div>
  )
}

export default Project