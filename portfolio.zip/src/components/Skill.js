import React from 'react'
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faHtml5} from "@fortawesome/free-solid-svg-icons"
function Skill() {

  // const Items = [
  //   {
  //     "icon": ""
  //   }
  // ]

  return (
    <>
    <div className='text-center mt-56 mb-24 text-4xl font-bold'>SKILL</div>
    <div></div>
    </>
  )
}

export default Skill